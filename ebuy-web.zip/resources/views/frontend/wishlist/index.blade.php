@extends('layouts.app')

@section('title', 'Wishlist')

@section('content')

    <livewire:frontend.wishlist-show/>

@endsection
