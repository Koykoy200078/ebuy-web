<div class="d-inline">
    {{ $productCount }}
</div>
